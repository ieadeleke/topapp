
export type ApiResponse = {
    message: string
}