export type FetchWalletTransactionsParams = {
    startDate?: string,
    endDate?: string,
    page?: number
}