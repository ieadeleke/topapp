export type ApiResponse = {
    banks: any
    message: string
}